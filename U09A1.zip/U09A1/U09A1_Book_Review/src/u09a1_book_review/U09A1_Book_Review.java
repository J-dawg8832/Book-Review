package u09a1_book_review;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Projections.fields;
import static com.mongodb.client.model.Projections.include;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bson.Document;

public class U09A1_Book_Review {

    public static void main(String[] args) {
        Logger log = Logger.getLogger(U09A1_Book_Review.class.getName());
        log.setLevel(Level.CONFIG);
        
        //Declare an empty string for the MongoURI
        String mongoURI = "";
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Username: ");
        String user = scanner.nextLine();
        System.out.print("Enter Password: ");
        String pass = scanner.nextLine();
        
        try{
            mongoURI = "mongodb://" + user + ":" + URLEncoder.encode(pass, "UTF-8") + 
                    "@localhost:27017/books";
        }
        catch(Exception ex) {
            log.log(Level.SEVERE, "Could not access database...");
        }
        
        //Set the name of the database that holds the information
        String database = "books";
        //Set the name of the collection that holds the data
        String collectionName = "bookInfo";
        
        //Create MongoDB client connection
        MongoClientURI mongoConnURI = new MongoClientURI(mongoURI);
        MongoClient mongoClient = new MongoClient(mongoConnURI);
        MongoDatabase mongoDB = mongoClient.getDatabase(database);
        MongoCollection<Document> collection = mongoDB.getCollection(collectionName);
        
        
        //Find a book in the bookInfo database
        ArrayList<String> id = new ArrayList<String>();
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the Title of a Book: ");
        String book = input.nextLine();
        
    
        
        //query to add the title as long as its in the database
        int referenceNum = 0;
        BasicDBObject query = new BasicDBObject();
        query.put("Title", 
                new BasicDBObject("$regex", book)
                .append("$options", "i"));
        MongoCursor<Document> cursor = collection.find(query)
                .iterator();
        
        //while loop to display all the book titles that have the specific set of characters in them 
        //specified in the query
        //and add them to the arraylist
        while(cursor.hasNext()) {
            Document bookInfo = cursor.next();
            referenceNum++;
            System.out.println(referenceNum + ") " + bookInfo.getString("Title"));
            id.add(bookInfo.getString("Title"));
        }
        
        //code to get the selection number and display information
        System.out.print("\nEnter selection number (0 to quit): ");
        Scanner inp = new Scanner(System.in);
        int choice = inp.nextInt();
        String bookNum;
        // choice not 0 and not too high
        if(choice > 0 && choice <= referenceNum) {
            bookNum = id.get(choice - 1);
        }
        else {
            bookNum = "0";
        }
    }
}
